using Godot;
using System;

public partial class area : Area2D
{
	[Export] int tipo=1;
	public void EntrouArea(Node2D corpo) {
		if (tipo == 1) {
			if (corpo is jogador) {
				((jogador)corpo).Dano(10);
			}
		}

		if (tipo == 2) {
			if (corpo is jogador) {
				if (((jogador)corpo).Vida(20)==true) {
					QueueFree(); //deleta esse objeto
				}
			}
		}
		
	}

}
