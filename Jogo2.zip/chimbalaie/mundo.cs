using Godot;
using System;

public partial class mundo : Node2D
{
	[Export] private Polygon2D p;
	[Export] private CollisionPolygon2D cp;
	public override void _Ready() {
		p.Polygon = cp.Polygon;
	}

}
